# Absolventska-prace-1.3
