document.getElementById("button").onclick = function(){
    
}